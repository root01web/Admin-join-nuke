-- Place ce script dans ServerScriptService

local Players = game:GetService("Players")
local Workspace = game:GetService("Workspace")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

-- Liste des UserIds admins
local ADMINS = {
    [12345678] = true, -- Remplace par l'UserId de ton admin/dev principal
    [87654321] = true, -- Ajoute d'autres UserIds si besoin
}

-- Crée le RemoteEvent pour afficher un message aux joueurs
local nukeEvent = Instance.new("RemoteEvent")
nukeEvent.Name = "NukeWarning"
nukeEvent.Parent = ReplicatedStorage

-- Fonction pour créer la bombe nucléaire
local function spawnNuke(targetPosition)
    local nuke = Instance.new("Part")
    nuke.Name = "NUKE"
    nuke.Size = Vector3.new(10, 30, 10)
    nuke.Color = Color3.fromRGB(200, 200, 0)
    nuke.Anchored = false
    nuke.Position = targetPosition + Vector3.new(0, 200, 0) -- tombe du ciel
    nuke.Parent = Workspace

    local bodyVelocity = Instance.new("BodyVelocity")
    bodyVelocity.Velocity = Vector3.new(0, -100, 0)
    bodyVelocity.MaxForce = Vector3.new(1e5, 1e5, 1e5)
    bodyVelocity.Parent = nuke

    -- Explosion à l'impact avec le sol
    nuke.Touched:Connect(function(hit)
        if hit:IsDescendantOf(Workspace.Terrain) or hit.Anchored then
            local explosion = Instance.new("Explosion")
            explosion.Position = nuke.Position
            explosion.BlastRadius = 60
            explosion.BlastPressure = 500000
            explosion.Parent = Workspace
            nuke:Destroy()
        end
    end)
end

-- Quand un joueur se connecte
Players.PlayerAdded:Connect(function(player)
    if ADMINS[player.UserId] then
        -- Message à tous les joueurs
        nukeEvent:FireAllClients(player.Name)
        -- Nuke descend au centre de la map (0,0,0)
        spawnNuke(Vector3.new(0, 0, 0))
    end
end)

-- CLIENT : pour afficher le message
-- À placer dans StarterPlayerScripts

if game:GetService("ReplicatedStorage"):FindFirstChild("NukeWarning") then
    game:GetService("ReplicatedStorage").NukeWarning.OnClientEvent:Connect(function(adminName)
        local StarterGui = game:GetService("StarterGui")
        StarterGui:SetCore("ChatMakeSystemMessage", {
            Text = "⚠️ Un dev (" .. adminName .. ") a rejoint, BOMBE NUCLÉAIRE ! ⚠️",
            Color = Color3.fromRGB(255, 0, 0),
            Font = Enum.Font.SourceSansBold,
            FontSize = Enum.FontSize.Size96
        })
    end)
end