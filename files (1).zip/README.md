# Roblox Nuke On Admin Join

Ce repository contient un script Roblox qui fait tomber une bombe nucléaire du ciel dès qu’un administrateur rejoint la partie, et affiche un message “Un dev a rejoint” à tous les joueurs.

## Fonctionnalités

- Surveillance des connexions admin (par UserId).
- Bombe nucléaire qui tombe du ciel au centre de la map avec explosion.
- Message d’alerte visible par tous les joueurs.
- Facile à personnaliser (position, UserIds, message, effet de la bombe).

## Installation

1. Place **NukeOnAdminJoin.lua** dans `ServerScriptService`.
2. Copie la partie client (à partir de "-- CLIENT") dans un script séparé dans `StarterPlayerScripts`, ou découpe le fichier si tu veux séparer les scripts.
3. Remplace les UserIds dans la variable `ADMINS` par ceux de tes admins/devs.
4. Lance le jeu, connecte-toi avec un compte admin, la bombe tombera automatiquement au centre de la map, et un message d’alerte s’affichera.

## Personnalisation

- Change la position de la bombe dans `spawnNuke(Vector3.new(0, 0, 0))` si tu veux qu’elle tombe ailleurs.
- Modifie le message dans la partie client pour un texte différent.
- Change les paramètres de l’explosion si tu veux plus ou moins de dégâts.

---

**Structure du repository :**
```
/
|-- NukeOnAdminJoin.lua
|-- README.md
```